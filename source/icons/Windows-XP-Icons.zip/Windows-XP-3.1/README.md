# WinXP-Icons
### This icon pack is a remake of the classic YlmfOS theme with some mods for icons to scale right

- All icons now scaling allright and some more icons included!

*screenshot*

![screenshot_2016-10-23_17-02-42](https://cloud.githubusercontent.com/assets/15310985/19629397/873d0644-9942-11e6-90f9-b55e618cda29.png)

